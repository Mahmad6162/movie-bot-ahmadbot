import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
import requests
import os

# Logging configuration
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Telegram bot token and TMDB API key from environment variables
bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
api_key = os.getenv('TMDB_API_KEY')

# Define states for conversation
SELECTING_MOVIE = 1

# Function to retrieve movie details from TMDB API
def get_movie_details(movie_id):
    try:
        movie_url = f'https://api.themoviedb.org/3/movie/{movie_id}?api_key={api_key}&language=en-US'
        credits_url = f'https://api.themoviedb.org/3/movie/{movie_id}/credits?api_key={api_key}'

        with requests.Session() as session:
            movie_response = session.get(movie_url)
            credits_response = session.get(credits_url)

        movie_data = movie_response.json()
        credits_data = credits_response.json()

        movie_data['cast'] = credits_data['cast']
        return movie_data
    except Exception as e:
        logger.error(f"Error retrieving movie details: {e}")
        return None

# Function to search for movies by name
def search_movies(movie_name):
    try:
        url = f'https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={movie_name}'
        with requests.Session() as session:
            response = session.get(url)
        return response.json()
    except Exception as e:
        logger.error(f"Error searching for movies: {e}")
        return None

# Function to format movie details for display
def format_movie_details(movie_data):
    title = movie_data.get('title', 'N/A')
    rating = movie_data.get('vote_average', 'N/A')
    overview = movie_data.get('overview', 'N/A')
    cast = ", ".join([actor['name'] for actor in movie_data.get('cast', [])[:5]])
    return f"Title: {title}\nRating: {rating}\nOverview: {overview}\nCast: {cast}"

# Function to split long messages
def split_message(message, chunk_size=4096):
    return [message[i:i + chunk_size] for i in range(0, len(message), chunk_size)]

# Handler functions
def start(update, context):
    update.message.reply_text("Welcome! Use /search to find a movie.")

def search(update, context):
    update.message.reply_text("Please send the name of the movie you want to search for.")
    return SELECTING_MOVIE

def select_movie(update, context):
    query = update.message.text
    results = search_movies(query)
    if results and 'results' in results:
        movies = results['results']
        if movies:
            movie_list = format_movie_list(movies)
            update.message.reply_text(movie_list)
            return SELECTING_MOVIE
    update.message.reply_text("No results found. Please try again.")
    return SELECTING_MOVIE

def format_movie_list(movies):
    formatted_list = ""
    for i, movie in enumerate(movies):
        title = movie.get('title', 'N/A')
        release_date = movie.get('release_date', 'N/A')
        movie_data = get_movie_details(movie['id'])
        if movie_data:
            overview = movie_data.get('overview', 'N/A')
            cast_names = ", ".join([actor['name'] for actor in movie_data['cast']][:5])
            formatted_list += f"{i + 1}. {title} ({release_date[:4]})\nOverview: {overview}\nCast: {cast_names}\n\n"
    return formatted_list

def unknown(update, context):
    update.message.reply_text("Sorry, I didn't understand that command.")

def main():
    updater = Updater(bot_token, use_context=True)
    dp = updater.dispatcher

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("search", search)],
        states={
            SELECTING_MOVIE: [MessageHandler(Filters.text & ~Filters.command, select_movie)]
        },
        fallbacks=[]
    )

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(conv_handler)
    dp.add_handler(MessageHandler(Filters.command, unknown))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()